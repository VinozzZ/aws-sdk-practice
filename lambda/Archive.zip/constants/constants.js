var constants = Object.freeze({
	appId: '',
	dynamoDBTableName: 'VoiceDevUsers',
	states:{
		ONBOARDING: '',
		MAIN: '_MAIN'
	}
});
module.exports = constants;